%****************************************************************************
% comparision of ISI and ICI-CIG.
% we conclude that if N_P -G << N_FFT then P_ISI is approximately equal to
% P_ICI_CIG  
%****************************************************************************

clear;

load h_decimation.am -ascii;
h = h_decimation;
%----------------------------------------------------------------------------- 
% System parameter
%-----------------------------------------------------------------------------


N_P = length(h);  % length of channel impulse response

index = 4:12;     % FFT length
N_FFT = 2.^index;
N_C = N_FFT;      % number of subcarriers
rho = h.^2;       % channel multipaths profile

rho=[rho,zeros(1,2^(max(index)) - N_P)];
E_S = 1;          % symbol energy


%----------------------------------------------------------------------------
%  Calculation of factor for P_ISI calculation
%  
%----------------------------------------------------------------------------

%---------------------------------------------
% The third term of P_ICI-CIG and P_ISI expression are similar, therefore
% they can be computed in the same step
% The third term of P_ICI-CIG = ICI_term3/N_FFT^2 + P_ISI
%--------------------------------------------------------

ISI = [ ];
ICI_term3 =[];
%for G=0:N_P-1;
for G=0:0;
ISI_G = 0;
        for i=0:N_P-G-1;
            
               
                    tau_bound = i+G;
                    for tau = tau_bound+1 : N_P-1; %%% important !!!!
                        ISI_G = ISI_G + rho(tau+1);
	            end;
	       
           
        end;
    


ISI = [ISI,ISI_G];
ICI_term3 = [ICI_term3,(G-N_P)*ISI_G];
end;


%--------------------------------------------------------------------------
% Calculation for term 2 of P_ICI-CIG 
%--------------------------------------------------------------------------
ICI_term2 = [ ];

%for G = 0:N_P-1;
for G = 0:0;

   ICI_G = 0;
      for i=0:N_P-G-1;
          for ix=0:N_P-G-1;
              
                    tau_bound = min(i+G,ix+G);
                    for tau = G:tau_bound;   %%% important !!!!!
                        ICI_G = ICI_G + rho(tau+1);
	            end;
                
	   
	     
           end;
      end;


ICI_term2 = [ICI_term2,ICI_G];

end;


%--------------------------------------------------------------------------
% Calculation of term1 of P_ICI-CIG
%--------------------------------------------------------------------------
ICI_term1 = [ ];
%for G = 0:N_P-1;
for G = 0:0;

   ICI_G = 0;
      for i=0:N_P-G-1;
          
              
                    for tau = G:i+G;   %%% important !!!!!
                        ICI_G = ICI_G + rho(tau+1);
	            end;
	        
	     
         
      end;

ICI_G = ICI_G *(N_P-G);
ICI_term1 = [ICI_term1,ICI_G];

end;

% k1 is the factor which corespends to  1/N_FFT^2
k1 = ICI_term1 -ICI_term2 + ICI_term3;

% k2 is the factor which corresponds to 1/N_FFT
k2 = ISI;

P_ISI = []
P_ICI2 = [];

for index = 4:12;
%for N_FFT = 16:16:4096;

N_FFT = 2^index;

P_ICI2 = [P_ICI2;E_S ./N_FFT^2 * k1 + E_S./N_FFT * k2]; 

P_ISI = [P_ISI;E_S./N_FFT * k2]; 


% both P_ISI and P_ICI2 is tested correctely on 19.03.02
end;

PI = P_ISI + P_ICI2;
%PI = 2*P_ISI
index = 4:12;
plot(index,10*log10(P_ISI(:,1)),'bx-');
hold on;


plot(index,10*log10(P_ICI2(:,1)),'r+-');

plot(index,10*log10(PI(:,1)),'ko-');


ylabel('Interference power in dB','FontSize',12);
xlabel('log_2(N_{FFT})','FontSize',12);
legend('ISI power','ICI-CIG power','Total interference power ');
grid on;

hold off;



%x = 16:16:4096;

%y = PI;

%z = [x;y'];

%save TwoTimeOfPISI.am z -ascii;
