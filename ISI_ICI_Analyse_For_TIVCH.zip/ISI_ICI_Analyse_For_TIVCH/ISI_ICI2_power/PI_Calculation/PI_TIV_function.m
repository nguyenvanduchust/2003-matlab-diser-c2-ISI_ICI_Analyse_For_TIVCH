%****************************************************************************
%   This program calculates theoretically the intersymbol and intercarriers
%   interference.
%   Van Duc Nguyen - 27, 11 2001 - IANT   
%****************************************************************************-

function[y]=PI_TIV_function(G);

clear;


%---------------------------------------------------------------------------
% Channel impulse response arccording to HIPERLAN specification
%--------------------------------------------------------------------------

h_o = [1, 0.9, 0.82224, 0.7413, 0.668, 0.6095, 0.549, 0.4954, 0.451, 0.407,...
     0.0,0.5821,0.0, 0.0, 0.4315,0.0, 0.0, 0.319, 0.0, 0.0, 0.23713,...
      0.0, 0.0, 0.0, 0.206, 0.0, 0.0, 0.0, 0.0, 0.12589, 0.0, 0.0, 0.0,...
       0.0, 0.07585, 0.0, 0.0, 0.0, 0.0, 0.04623];

% The channel coefficients are piceweise interpolated

i1=     interp1([1,3],[0.407,0.5821],[1,2,3]) 
i2=     interp1([1,4],[0.5821,0.4315],[1,2,3,4])
i3=     interp1([1,4],[0.4315,0.319],[1,2,3,4])
i4=     interp1([1,4],[0.319,0.23713],[1,2,3,4])
i5=     interp1([1,5],[0.23713,0.206],[1,2,3,4,5])
i6=     interp1([1,6],[0.206,0.12589],[1,2,3,4,5,6]) 
i7=     interp1([1,6],[0.12589,0.07585],[1,2,3,4,5,6])
i8=     interp1([1,6],[0.07585,0.04623],[1,2,3,4,5,6])
h_i = [1, 0.9, 0.82224, 0.7413, 0.668, 0.6095, 0.549, 0.4954, 0.451,...
	i1(1:2),i2(1:3),i3(1:3),i4(1:3),i5(1:4),i6(1:5),i7(1:5),i8(1:6)]
clear i1,i2,i3,i4,i5,i6,i7,i8;    

h = [h_i(1:5:40),h_i(40)]; %channel impulse response after decimation

%----------------------------------------------------------------------------- 
% System parameter
%-----------------------------------------------------------------------------

Oversampling_factor = 5;
t_a = 50e-9;      % sampling duration
N_P = length(h);  % length of channel impulse response
N_C = 64;         % number of subcarriers
N_FFT = 64;       % FFT length

rho = h.^2;       % channel multipaths profile

rho=[rho,zeros(1,N_FFT - N_P)];
E_S = 1;          % symbol energy


%----------------------------------------------------------------------------
%  Calculation of ISI power
%----------------------------------------------------------------------------

  
% caculated for ISI at  lth output of the FFT demodulator, see eq. 36
%  in the paper ' Intercarrier and intersymbol interference analysis of OFDM 
%  systems over fading channel
l = 32;





P_ISI_G = 0;
        for i=0:N_P-G-1;
            for ix=0:N_P-G-1;
                for n=0:N_C-1;
                    tau_bound = max(i+G,ix+G);
                    for tau = tau_bound +1 : N_P-1; %%% important !!!!
                        P_ISI_G = P_ISI_G + rho(tau+1)* exp(j*2*pi*(n-l)*(i-ix)/N_FFT);
	            end;
	        end;
            end;
        end;
    
P_ISI_G = E_S /N_FFT^2 .* P_ISI_G;



%--------------------------------------------------------------------------
% Calculation of ICI2 +ID power, term 1
%--------------------------------------------------------------------------


   P_1_G = 0;
      for i=0:N_P-G-1;
          for ix=0:N_P-G-1;
              for n=0:N_C-1;
                 tau_bound = min(i+G,ix+G);
                 for tau = G:tau_bound;   %%% important !!!!!
                    P_1_G = P_1_G + rho(tau+1)* exp(j*2*pi*(n-l)*(i-ix)/N_FFT);
	         end;
	   
	      end;
           end;
      end;

P_1_G = E_S /N_FFT^2 .* P_1_G;



%--------------------------------------------------------------------------
% Calculation of ICI2+ID power, term2
%--------------------------------------------------------------------------


   P_2_G = 0;
      for i=0:N_P-G-1;
          for ix=N_P-G:N_C-1;
              for n=0:N_C-1;
                 if n~=l
                 
                    for tau = G:i+G;   %%% important !!!!!
                        P_2_G = P_2_G + rho(tau+1)* exp(-j*2*pi*(n-l)*(i-ix)/N_FFT);
	            end;
	         end;
	      end;
           end;
      end;

P_2_G = E_S /N_FFT^2 .* P_2_G;



%--------------------------------------------------------------------------
% Calculation of ICI2+ID power, term 3
%--------------------------------------------------------------------------

   P_3_G = 0;
      for i=N_P-G:N_C-1;
          for ix=0:N_P-G-1;
              for n=0:N_C-1;
                 if n~=l
                 
                    for tau = G:ix+G;   %%% important !!!!!
                        P_3_G = P_3_G + rho(tau+1)* exp(-j*2*pi*(n-l)*(i-ix)/N_FFT);
	            end;
	         end;
	      end;
           end;
      end;

P_3_G = E_S /N_FFT^2 .* P_3_G;


%--------------------------------------------------------------------------
% Calculation of ICI2+ID power, term4
%--------------------------------------------------------------------------

   P_4_G = 0;
      for i=N_P-G:N_C-1;
          for ix=N_P-G:N_C-1;
              for n=0:N_C-1;
                 if n~=l
                 
                    for tau = G:N_P-1;   %%% important !!!!!
                        P_4_G = P_4_G + rho(tau+1)* exp(j*2*pi*(n-l)*(i-ix)/N_FFT);
	            end;
	         end;
	      end;
           end;
      end;

P_4_G = E_S /N_FFT^2 .* P_4_G;



y =P_1_G+P_2_G +P_3_G+P_4_G+ P_ISI_G;
