

1. PI_Calculation.m: Theoretical calculation of ISI, ICI2, ID powers

% however, on 14 march after discussion with Prof. Kuchenbecker I have
% realised that the ID can be considered as multiplicative distortion
% therefore the file 

2. P_ICI_CIG_ISI.m is porgramed to calculate only ICI-CIG and ISI powers



3. ComparisonOfISIandICI2.m compare the ISI and ICI2 powers. We concluded that
   if tau_max - G << T_S then P_ISI is approximately equal to P_ICI2.




