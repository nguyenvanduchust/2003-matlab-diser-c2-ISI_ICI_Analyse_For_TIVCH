%--------------------------------------------------------------------------
% This program computes the interfence power (ISI+ICI2) for the case of
% static and uncorrelated scatering channel
% Van Duc 27.11.01
% changed on 15.03.02 because ID belongs to useful distribution
% changed on 31.05.02 for using QASK symbol created by Matlab
%-------------------------------------------------------------------------

clear;
%------------------------------------------------
% system parameter
%-----------------------------------------------
N_C = 64;
N_FFT = 64;
NOfExperiment =100; % smaller than 100


%-------------load the QPSK symbol obtained in COSSAP--------------------

%load QPSK_Symbol_Real.am -ascii;
%load  QPSK_Symbol_Img.am -ascii;
%-----------------------------------------------------------------------
%-------------QASK is created by matlab--------------------------------
M_ary =4; 

length_data = NOfExperiment*N_FFT;
source_data = randint(length_data,2);

symbols = bi2de(source_data);  
%----------------------------------------------------------------
% QASK modulator in base band
%---------------------------------------------------------------
QPSK_Symbol = dmodce(symbols,1,1,'qask',M_ary);



%QPSK_Symbol_Real =  QPSK_Symbol_Real(:,2);
%QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);


%QPSK_Symbol = QPSK_Symbol_Real' + j*QPSK_Symbol_Img';

%QPSK_Symbol= QPSK_Symbol(1:N_FFT*NOfExperiment);

d_frame = [];
for i=1:N_C:length(QPSK_Symbol);
    d_i = [];
    for k=i:i+N_C-1;
        d_i = [d_i, QPSK_Symbol(k)];
    end;
    d_frame = [d_frame;d_i];
end;
 

%--------------------------------------------
% channel coefficients
%-------------------------------------------
load h_decimation.am -ascii;


N_P = length(h_decimation); % the length of channel impulse response

%--------------------------------------------
% uncorrelated scatering when the channel matrix h = [h1;h2;....;hn],
% where E{h1}=h(1); and  E{h1*h2} = 0
%--------------------------------------------

%NOfExperiment = length(QPSK_Symbol)/N_FFT; % Number of experiments should be performed



P_I = [];
d_isi_vector =[];
d_ici_vector = [];
for G=0:N_P-1; % loop of guard length

%-----------------------------------------------------------
% The channel coefficient matrix will be prepared
%----------------------------------------------------------

h_uncorr = [];

for i=1:N_P;   
     %ch_coeff_real = randn(1,NOfExperiment)*sqrt(h_decimation(i)^2/2);
     %ch_coeff_img = randn(1,NOfExperiment)*sqrt(h_decimation(i)^2/2);
     %ch_coeff =ch_coeff_real+j*ch_coeff_img;
     %h_uncorr = [h_uncorr; ch_coeff];
  
     h_uncorr = [h_uncorr; h_decimation(i)*exp(j*2*pi*rand(1,NOfExperiment))];

% The channel coefficient of each path having the random phase and 
% constant amplitude h(i)

end;


%---------------------------------------------------------
% Now, the interfence power will be computed for each experiment. In  
% each experiment, the channel coefficient of each path is statistical
% independent, the two diferent paths are uncorrelated scatering 
%--------------------------------------------------------

d_i = [];
d_u = [];
for loop=1:NOfExperiment     %****** Loop 1 *******
    h = h_uncorr(:,loop)';
    h1 = [h(1:G),zeros(1,N_P-G),zeros(1,N_FFT-N_P)];
    h2 = [zeros(1,G),h(G+1:N_P),zeros(1,N_FFT-N_P)];
    H1 = fft(h1);
    H2 = fft(h2);
    H = H1 + H2 * (N_FFT-N_P+G)/N_FFT;

%--------------------------------------------------
% calculation of ICI consists of d_term2 and d_term3
%---------------------------------------------------
% 1> calculation of H_term3 matrix, tested and correctly
% Van Duc 15.10.01
%----------------------------------------------------


H_term3 = [];
for l=0:N_C-1;
H_term3_n =[];
for n=0:N_C-1;

H_term3_tem = 0;
	for i=0:N_P-G-1;  
             if (n~=l)   % changed on 15.03.02       	    
        	for tau = G : i+G; 
             	   	H_term3_tem = H_term3_tem + 1/N_FFT*h2(tau+1)* exp(-j*2*pi*tau*n/N_FFT)*exp(j*2*pi*(n-l)*i/N_FFT);        
	    	 end;
	     end;
	end;

H_term3_n = [H_term3_n;H_term3_tem];
end;
H_term3 = [H_term3,H_term3_n];
end;

%---------------------------------------
% Calculation of H_term 2 matrix
%--------------------------------------

H_term2=[];
for l=0:N_FFT-1;
H_term2_n=[];
   for n=0:N_C-1;
       H_term2_tem = 0;
       for i= N_P - G+1:N_C;
           if(n~=l)
             H_term2_tem = H_term2_tem + 1/N_FFT * H2(n+1)*exp(j*2*pi*(n-l)*(i-1)/N_FFT);
           end;
       end;
    H_term2_n=[H_term2_n; H_term2_tem];
    end;
     H_term2= [ H_term2,H_term2_n];
 end; 

clear H_term2_tem,H_term2_n; 
  
H_ICI2 = H_term3 +H_term2; % ICI2 matrix 


%------------------------------------------------------------------
% caculate ISI matrix. The calculation was tested and corectly 
%  Van Duc 15.10.01, the formular adoted from paper in Hamburg
%-----------------------------------------------------------------

H_ISI = [];
for l=0:N_FFT-1;
H_ISI_n = [];
for n =0:N_FFT-1;
    H_tem = 0;
    for nt = N_FFT+G: N_FFT+N_P-1;    
        for tau = nt-N_FFT+1:N_P-1;
                   H_tem = H_tem + 1/N_FFT*h2(tau+1)*exp(j*2*pi*n*(nt-tau)/N_FFT)*exp(-j*2*pi*l*(nt-N_FFT-G)/N_FFT);          
        end;    
end;
H_ISI_n = [H_ISI_n; H_tem];
end;
H_ISI = [H_ISI,H_ISI_n];
end; 
clear H_ISI_n, H_tem;




%---------------------------------------------------------------------------
% calculation of d_ICI, d_u 
%---------------------------------------------------------------------------
    d_current = d_frame(loop,:);

    d_ICI = d_current* H_ICI2 ; %d_ICI2+d_ID
    d_u_current = d_current.* H;
    d_u = [d_u,d_u_current];



%-------------------------------------------------------------------------
% calculation of ISI
%------------------------------------------------------------------------
if loop ==1
   d_ISI = zeros(1,N_FFT); % first OFDM symbol contains no ISI
else
   d_previous = d_frame(loop-1,:);
   d_ISI = d_previous*H_ISI ;
end;

%----------------------------------------------------------------------
% calculation of interfernce symbol d_i
%---------------------------------------------------------------------

d_i_current = d_ICI + d_ISI;

d_i = [d_i,d_i_current];


end;
d_total = d_u + d_i;

d_isi_vector = [d_isi_vector,d_ISI];
d_ici_vector = [d_ici_vector,d_ICI];

P_I_current = sum(abs(d_i).^2)/(NOfExperiment*N_FFT); % average interference power
P_I = [P_I,P_I_current]


clear d_i, d_u, d_total,P_I_current,d_ISI, d_ICI, H_ISI, H_ICI2, H;

end;


plot(0:8,real(10*log10(P_I/2)),'r.-');

% if we used QASK symbol, then var(QPSK_Symbol)=2, P_I need to be divided by factor 2


zoom on;
grid on;
legend('Interference power');


%---------------------------------------------------------------
% Conclusion: interfernce power  for uncorrelated 
% scatering case is the same on all subcarrier
%--------------------------------------------------------------




