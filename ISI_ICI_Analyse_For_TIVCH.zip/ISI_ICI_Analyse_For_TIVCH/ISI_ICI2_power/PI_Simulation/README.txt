
First version on 27.11.01 

file: PI_Simulation.m  

ISI, ICI2+ID calculation power for static uncorrelated scatering channel

Second version written on 15.03.02

file: P_ICI2_ISI_Simulation.m

The ID power is excluded in the total interference power


Third version written on 31.05.02
file PI_Ray_Amp.m:

The channel is modeled with channel coefficient having  rayleigh distribution 



