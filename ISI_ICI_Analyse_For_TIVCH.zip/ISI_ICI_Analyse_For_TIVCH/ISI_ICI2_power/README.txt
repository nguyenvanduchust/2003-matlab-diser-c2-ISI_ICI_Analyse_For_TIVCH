

PI_Calculation:  Theoretical calculation of  ISI, ICI2+ID power


PI_Simulation:  Simulation for uncorrelated scatering channel



