%****************************************************************************
% This program calculates the ISI and ICI2 matrix, which are needed for the ISI
% and ICI2 cancellation algorithm 
% See reference the formulars of ISI and ICI2 in the paper 
% ' Intercarrier and Intersymbol Interference Analysis of OFDM System over
% Fading Channel' published in Hamburg -2001 
% written by Van Duc Nguyen on 06.12.01
%***************************************************************************

clear;
%------------------------------------------------
% system parameter
%-----------------------------------------------
N_C = 64;
G =0; % The guard length are set manually 
N_FFT = 64;

%--------------------------------------------
% channel coefficients
%-------------------------------------------

load h_decimation.am -ascii;

h = h_decimation;
%h=[0,2,1,1.2,0.4,0.9,0.3,0.1,0.5]
N_P = length(h); 
if G==0
   h2o = h;
   h2  =[h,zeros(1,N_C-N_P)];
   H2 = fft(h2);
else
   h2o = [zeros(1,G),h(G+1:N_P)];
   h2 = [zeros(1,G),h(G+1:N_P),zeros(1,N_C-N_P)];
   H2 = fft(h2);
end



%--------------------------------------------------
% calculation of ICI consists of d_term2 and d_term3
%---------------------------------------------------
% 1> calculation of H_term3 matrix, tested and correctly
% Van Duc 15.10.01
%----------------------------------------------------


l = 0;
H_term3 = [];
for l=0:N_C-1;
H_term3_n =[];
for n=0:N_C-1;
H_term3_tem = 0;
	for i=0:N_P-G-1;          	    
        	for tau = G : i+G; 
             	   	H_term3_tem = H_term3_tem + 1/N_FFT*h2(tau+1)* exp(-j*2*pi*tau*n/N_FFT)*exp(j*2*pi*(n-l)*i/N_FFT);        
	    	 end;
	      
	end;

H_term3_n = [H_term3_n;H_term3_tem];
end;
H_term3 = [H_term3,H_term3_n];
end;

%---------------------------------------
% Calculation of H_term 2 matrix
%--------------------------------------

H_term2=[];
for l=0:N_FFT-1;
H_term2_n=[];
   for n=0:N_C-1;
       H_term2_tem = 0;
       for i= N_P - G+1:N_C;
           if(n~=l)
             H_term2_tem = H_term2_tem + 1/N_FFT * H2(n+1)*exp(j*2*pi*(n-l)*(i-1)/N_FFT);
           end;
       end;
    H_term2_n=[H_term2_n; H_term2_tem];
    end;
     H_term2= [ H_term2,H_term2_n];
 end; 

clear H_term2_tem,H_term2_n; 
  
H_ICI2 = H_term3 +H_term2; % ICI2 matrix 


%------------------------------------------------------------------
% caculate ISI matrix. The calculation was tested and corectly 
%  Van Duc 15.10.01, the formular adoted from paper in Hamburg
%-----------------------------------------------------------------

H_ISI = [];
for l=0:N_FFT-1;
H_ISI_n = [];
for n =0:N_FFT-1;
    H_tem = 0;
    for nt = N_FFT+G: N_FFT+N_P-1;    
        for tau = nt-N_FFT+1:N_P-1;
                   H_tem = H_tem + 1/N_FFT*h2o(tau+1)*exp(j*2*pi*n*(nt-tau)/N_FFT)*exp(-j*2*pi*l*(nt-N_FFT-G)/N_FFT);          
        end;    
end;
H_ISI_n = [H_ISI_n; H_tem];
end;
H_ISI = [H_ISI,H_ISI_n];
end; 
clear H_ISI_n, H_tem;

%----------------------------------------------------------------
% Convert the ISI and ICI2 matrix to COSSAP format needed for the 
% model 'MUL_M_CM_QC' in file 'ISI_cancel_algorithm1_HIPChannel.sch in COSSAP
% (see model definition)
%---------------------------------------------------------------

H_ISI_COSSAP = [];

for i=1:N_FFT;
    for j=1:N_FFT;
        H_ISI_COSSAP = [H_ISI_COSSAP,real(H_ISI(i,j)),imag(H_ISI(i,j))];
    end;
end;

H_ICI2_COSSAP = [];

for i=1:N_FFT;
    for j=1:N_FFT;
        H_ICI2_COSSAP = [H_ICI2_COSSAP,real(H_ICI2(i,j)),imag(H_ICI2(i,j))];
    end;
end;

%-------------------------------------------------------------------------
% H_ISI_COSSAP and H_ICI2_COSSAP is saved in hard disk by command:
% save H_ISI_COSSAP_TG0.am H_ISI_COSSAP -ascii
% then copy to the COSSAP directory and run the ISI cancellation in COSSAP
%------------------------------------------------------------------------

surf(abs(H_ISI));
xlabel('l ','FontSize',12);
ylabel('n ','FontSize',12);
zlabel('|H^{ISI}(n,l)|','FontSize',12);

daten = abs(H_ISI);
save C5_H_ISI_Matrix.am daten -ascii;
