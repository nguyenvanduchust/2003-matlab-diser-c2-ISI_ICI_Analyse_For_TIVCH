%****************************************************************************
% This program cancallate the ISI and ICI2 including ID after algorithm 2
% The data created by COSSAP in circuit ISI_cancellation.sch is imported.
% The algorithm 2 is:
% 1.  The initial phase:  subtract ICI2 from first received signal 
% 2.  Calculate ISI and ICI2 simultaneously  based on the  received signal
% 3.  Subtract ICI2, and ISI from  the  received signal
% This program is written on 15.11.01 by Van Duc Nguyen
% modified on 03.11.01 by Van Duc Nguyen
% We have compared algorithm 1,and 2. The result is that performance of 
% algorithm 1 is better than algorithm2
%***************************************************************************
clear;
%------------------------------------------------
% system parameter
%-----------------------------------------------
N_C = 64;
G =3;
N_FFT = 64;

%-----------------------------------------------
% The transmitted symbol is loaded from ISI_canelattion file from COSSAP
%----------------------------------------------

load QPSK_Symbol_Img.am -ascii;
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);
load QPSK_Symbol_Real.am -ascii;
QPSK_Symbol_Real = QPSK_Symbol_Real(:,2);
QPSK_Symbol = QPSK_Symbol_Real' + j*QPSK_Symbol_Img';
QPSK_S1 =  QPSK_Symbol(1:64);


%------------------------------------------------------------------
% After traveling through multipath channel, the reveived signal
% with presence of ISI, ICI is loaded
%-----------------------------------------------------------------

load received_signal_img.am -ascii; % received signal before equalizer
load received_signal_real.am -ascii;

received_signal_img = received_signal_img(:,2);
received_signal_real = received_signal_real(:,2);

%---------------------------------------------------------------
% The received QPSK symbol, which is obtained by multiplying H^-1 with
% the received signal, is loaded
%---------------------------------------------------------------

load Received_QPSK_Symbol_Img.am -ascii;
load Received_QPSK_Symbol_Real.am -ascii;
Received_QPSK_Symbol_Img = Received_QPSK_Symbol_Img(:,2);
Received_QPSK_Symbol_Real = Received_QPSK_Symbol_Real(:,2);

Received_QPSK_Symbol = Received_QPSK_Symbol_Real' + j*Received_QPSK_Symbol_Img';
Received_QPSK_Symbol1 = Received_QPSK_Symbol(1:64);

Received_QPSK_Symbol2 = Received_QPSK_Symbol(65:128);



signal = received_signal_real' + j*received_signal_img'; % received data
signal1 = signal(1:64);
signal2 = signal(65:128);
signal_frame = [];

%--------------------------------------------------------
% The recieved signal is changed to a matrix [ofdm_symbol1;...; ofdm_symboln]
%-------------------------------------------------------
for i=1:N_C:length(signal);
    signal_i = [];
    for k=i:i+N_C-1;
        signal_i = [signal_i, signal(k)];
    end;
    signal_frame = [signal_frame;signal_i];
end;

%------------------------------------------------------
% The received QPSK symbol is also changed to a matric format 
%------------------------------------------------------
Received_QPSK_Symbol_frame = [];
for i=1:N_C:length(Received_QPSK_Symbol);
    Received_QPSK_Symbol_i = [];
    for k=i:i+N_C-1;
        Received_QPSK_Symbol_i = [Received_QPSK_Symbol_i,Received_QPSK_Symbol(k)];
    end;
     Received_QPSK_Symbol_frame = [Received_QPSK_Symbol_frame;Received_QPSK_Symbol_i];
end;
%--------------------------------------------


%--------------------------------------------
% channel coefficients
%-------------------------------------------
load h_decimation.am -ascii;

h = h_decimation;
%h = [1,0,0,0,0,0,0,0,0.5];
N_P = length(h); 
h1 = [h(1:G),zeros(1,N_C-G)];
h2o = [zeros(1,G),h(G+1:N_P)];
h2 = [zeros(1,G),h(G+1:N_P),zeros(1,N_C-N_P)];
H1 = fft(h1);
H2 = fft(h2);
H1H2 = H1 + H2 * (N_C+N_P -G)/N_C;
H = H1 + H2;
%--------------------------------------------------
% calculation of ICI consists of d_term2 and d_term3 for the first symbol.
% This symbol, of course, doesn't containts ISI
%---------------------------------------------------
% 1> calculation of H_term3 matrix, tested and correctly
% Van Duc 15.10.01
%----------------------------------------------------



H_term3 = [];
for l=0:N_C-1;
H_term3_n =[];
for n=0:N_C-1;
H_term3_tem = 0;
	for i=0:N_P-G-1;          	    
        	for tau = G : i+G; 
             	   	H_term3_tem = H_term3_tem + 1/N_FFT*h2(tau+1)* exp(-j*2*pi*tau*n/N_FFT)*exp(j*2*pi*(n-l)*i/N_FFT);        
	    	 end;
	      
	end;

H_term3_n = [H_term3_n;H_term3_tem];
end;
H_term3 = [H_term3,H_term3_n];
end;


%---------------------------------------
% Calculation of H_term 2 matrix
%--------------------------------------

H_term2=[];
for l=0:N_FFT-1;
H_term2_n=[];
   for n=0:N_C-1;
       H_term2_tem = 0;
       for i= N_P - G+1:N_C;
           if(n~=l)
             H_term2_tem = H_term2_tem + 1/N_FFT * H2(n+1)*exp(j*2*pi*(n-l)*(i-1)/N_FFT);
           end;
       end;
    H_term2_n=[H_term2_n; H_term2_tem];
    end;
     H_term2= [ H_term2,H_term2_n];
 end;   


H_ICI2 = H_term3 +H_term2;
d_ICI2 = Received_QPSK_Symbol1 *H_ICI2;

d_cancellation = signal1 - d_ICI2;
d_equalized = d_cancellation *1./H;
clear d_ICI2;


%------------------------------------------------------------------
% caculate ISI matrix. The calculation was tested and corectly 
%  Van Duc 15.10.01
%-----------------------------------------------------------------

H_ISI = [];
for l=0:N_FFT-1;
H_ISI_n = [];
for n =0:N_FFT-1;
    H_tem = 0;
    for nt = N_FFT+G: N_FFT+N_P-1;    
        for tau = nt-N_FFT+1:N_P-1;
                   H_tem = H_tem + 1/N_FFT*h2o(tau+1)*exp(j*2*pi*n*(nt-tau)/N_FFT)*exp(-j*2*pi*l*(nt-N_FFT-G)/N_FFT);          
        end;    
end;
H_ISI_n = [H_ISI_n; H_tem];
end;
H_ISI = [H_ISI,H_ISI_n];
end; 

%--------------------------------------------------------------
% calculate ISI, ICI2 for a frame
%-------------------------------------------------------------

for loop=1:floor(length(Received_QPSK_Symbol)/N_C)-1;
    d1 = Received_QPSK_Symbol_frame(loop,:);
    d2 = Received_QPSK_Symbol_frame(loop+1,:);
    signal1 = signal_frame(loop,:);
    signal2 = signal_frame(loop+1,:);


%-------------------------------------------------------------
% Caculation of d_term2, d_term3 for the current symbol
%------------------------------------------------------------


   d_ICI2 = d2 * H_ICI2;
   d_ISI = d1 * H_ISI;

   d_ICI_ISI_cancel = signal2 -d_ICI2-d_ISI;



%---------------------------------------------------
% After subtracting ISI and ICI, the subtracted signal need to be equalized
%---------------------------------------------------

   d_equalized_current_symbol = d_ICI_ISI_cancel * 1./H;
   d_cancellation = [d_cancellation; d_ICI_ISI_cancel];
   d_equalized = [d_equalized;d_equalized_current_symbol];
end;



H_ISI_COSSAP = [];

for i=1:N_FFT;
    for j=1:N_FFT;
        H_ISI_COSSAP = [H_ISI_COSSAP,real(H_ISI(i,j)),imag(H_ISI(i,j))];
    end;
end;

H_ICI2_COSSAP = [];

for i=1:N_FFT;
    for j=1:N_FFT;
        H_ICI2_COSSAP = [H_ICI2_COSSAP,real(H_ICI2(i,j)),imag(H_ICI2(i,j))];
    end;
end;


d_eq = [];
for loop=1:floor(length(Received_QPSK_Symbol)/N_C);

d_eq = [d_eq,d_equalized(loop,:)];
end;
%----------------------------------
% put result in screen
%---------------------------------

mse = sum(abs(d_eq - QPSK_Symbol).^2);

plot(real(d_eq),'r.-');
hold on;
plot(Received_QPSK_Symbol_Real,'kx');

legend('received symbol with ISI and ICI_2 cancellation','original received symbol');
hold off;
zoom on;
grid on;






