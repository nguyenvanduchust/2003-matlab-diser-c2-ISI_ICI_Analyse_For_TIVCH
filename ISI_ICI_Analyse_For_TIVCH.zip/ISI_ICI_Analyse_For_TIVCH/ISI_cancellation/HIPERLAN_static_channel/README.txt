

-- In this directory, the static HIP/2 is performed --

1/  ComparationOfCosMatResults.m  compares signal obtained in COSSAP with theoretical calculation.


2/ ISI_cancel_algorithm1.m : ISI cancellation according to algorithm 1


3/ ISI_cancel_algorithm2.m : ISI cancellation according to algorithm 2


4/ SI_ICI2_Matrix_Calculation.m :  calculate the ISI and ICI2 matrix needed for COSSAP simulation



