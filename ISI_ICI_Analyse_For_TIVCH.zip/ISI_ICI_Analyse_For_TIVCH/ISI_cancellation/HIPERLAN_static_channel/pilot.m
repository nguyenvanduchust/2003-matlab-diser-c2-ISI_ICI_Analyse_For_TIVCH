

N =64;
D_f =4;
M = N/D_f;

amplitude = 1;
pilot_pattern = [];
for i = 1:M;
pilot_pattern = [pilot_pattern,amplitude];
for k = 1:D_f-1;
pilot_pattern = [pilot_pattern,0];
end;
end;
