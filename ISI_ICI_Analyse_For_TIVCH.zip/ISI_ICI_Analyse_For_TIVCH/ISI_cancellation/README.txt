


 1/   HIPERLAN_static_channel: ISI cancellation for static HIP/2


 2/   TwoPathChannel : ISI cancellation for static two paths channel



