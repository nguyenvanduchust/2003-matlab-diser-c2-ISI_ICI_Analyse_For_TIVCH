%--------------------------------------------------------------------------
% This program computes the received signal in Matlab, them compares this
% results with COSSAP. The received signal is not equalized
%-------------------------------------------------------------------------
clear;
%------------------------------------------------
% system parameter
%-----------------------------------------------
N_C = 64;
N_FFT = 64;
G =3;


%-------------load the QPSK symbol obtained in COSSAP--------------------

load QPSK_Symbol_Real.am -ascii;
load  QPSK_Symbol_Img.am -ascii;
load received_signal_img.am -ascii; % received signal before equlizer
load  received_signal_real.am -ascii;


QPSK_Symbol_Real =  QPSK_Symbol_Real(:,2);
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);
received_signal_img = received_signal_img(:,2);
received_signal_real = received_signal_real(:,2);

QPSK_Symbol = QPSK_Symbol_Real' + j*QPSK_Symbol_Img';
received_signal = received_signal_real' + j*received_signal_img'; % received data befor equalizer


d_frame = [];
for i=1:N_C:length(QPSK_Symbol);
    d_i = [];
    for k=i:i+N_C-1;
        d_i = [d_i, QPSK_Symbol(k)];
    end;
    d_frame = [d_frame;d_i];
end;
 

%--------------------------------------------
% channel coefficients
%-------------------------------------------
load h_decimation.am -ascii;
%h = h_decimation;
h = [1,0,0,0,0,0,0,0,0.5];
N_P = length(h); 
h1 = [h(1:G),zeros(1,N_P-G),zeros(1,N_FFT-N_P)];
h2 = [zeros(1,G),h(G+1:N_P),zeros(1,N_FFT-N_P)];
H1 = fft(h1);
H2 = fft(h2);
%H = H1 + H2 * (N_FFT-N_P+G)/N_FFT;

%******************************************************************
% Caculation of the first received  symbol. This symbol, of course,
% doesn't containt the ISI term
%******************************************************************

%------------------------------------------------------------------
% Calculation of d_term3 according to equation (31), correctly
% Van Duc 12.10.01
%--------------------------------------------------------------------------
d_term3 = [];
data = d_frame(1,:);
for l=0:N_C-1;
	d_term3_tem = 0;
	for i=0:N_P-G-1;    
% for example, if N_P =9, G=3 then the channel coeeficients in the positions 
% [4,5,6,7,8,9] caused ICI_2, this correspondes to the positions [0,1,2,3,4,5]
% in the area I (see in paper published in OFDM workshop 2001) of y_i2(t)
      	    for n=0:N_C-1;
        	for tau = G : i+G; 
             	   	d_term3_tem = d_term3_tem + 1/N_FFT*data(n+1)*h2(tau+1)* exp(-j*2*pi*tau*n/N_FFT)*exp(j*2*pi*(n-l)*i/N_FFT);        
	    	 end;
	    end;  
	end;
d_term3 = [d_term3,d_term3_tem];
end;


%-----------------------------------------------------
% Calculation of d_term2 according to equation (28,29)
%--------------------------------------------------------------------------

d_term2 = [];

for l=0:N_C-1;
    d_term2_tem = 0;
    for i= N_P - G+1:N_C;
    for n=0:N_C-1;
           if(n~=l)
           d_term2_tem = d_term2_tem + 1/N_FFT * data(n+1)*H2(n+1)*exp(j*2*pi*(n-l)*(i-1)/N_FFT);
           end;
    end;
    end;
    d_term2 = [d_term2,d_term2_tem];
end; 
    

d_ICI = d_term3 + d_term2;

%---------------------------------------------------------------------------
% Calculate the useful sinal, when the guard length is insufficient according 
% to  eq. (13) 
%---------------------------------------------------------------------------


d_u1 = data .* H1;
d_u2 = data .* H2 * (N_FFT-N_P+G)/N_FFT;
d_total = d_u1+d_u2 +d_ICI ;

clear d_term2_tem,  d_term3_tem ;


%***************************************************************************
% calculation of d_ISI, d_ICI, d_u for an OFDM frame
%**************************************************************************
d_Cancellation = d_total;

for loop=1:floor(length(QPSK_Symbol)/N_C)-1;
    d1 = d_frame(loop,:);
    d2 = d_frame(loop+1,:);

%-----------------------------------------------------
% Calculation of d_term3 according to equation (31)
%--------------------------------------------------------------------------

d_term3 = [];
for l=0:N_C-1;
	d_term3_tem = 0;
	for i=0:N_P-G-1;    %??? i=0:N_P-G-1 ok???
    	    for n=0:N_C-1;
        	for tau = G : i+G; %??? G+1: i+G ???
             	   	d_term3_tem = d_term3_tem + 1/N_FFT*d2(n+1)*h(tau+1)* exp(-j*2*pi*tau*n/N_FFT)*exp(j*2*pi*(n-l)*i/N_FFT);        
	    	 end;
	    end;  
	end;
d_term3 = [d_term3,d_term3_tem];
end;

%-----------------------------------------------------
% Calculation of d_term2 according to equation (29)
%--------------------------------------------------------------------------
 
d_term2 =[];
for l=0:N_C-1;
    d_term2_tem = 0;
    for i= N_P - G+1:N_C;
    for n=0:N_C-1;
           if(n~=l)
           d_term2_tem = d_term2_tem + 1/N_FFT * d2(n+1)*H2(n+1)*exp(j*2*pi*(n-l)*(i-1)/N_FFT);
           end;
    end;
    end;
    d_term2 = [d_term2,d_term2_tem];
end; 

d_ICI = d_term3 + d_term2;
clear d_term3, d_term2, d_term2_tem, d_term3_tem;


d_u1 = d2 .* H1;
d_u2 = d2 .* H2 *(N_FFT-N_P+G)/N_FFT;


%---------------------------------------------------------------------------
% Calculate the useful sinal, when the guard length is insufficient according 
% to  eq. (13) 
%---------------------------------------------------------------------------



%-------------------------------------------------------------------------
% calculation of ISI
%------------------------------------------------------------------------



d_ISI = [];
for l = 0:N_FFT-1;
    d_ISI_tem = 0;
    for i=N_FFT+G:N_FFT+N_P-1;
       	   for n=0:N_FFT-1;
             	for tau = i-N_FFT +1: N_P-1; %seting bounds of G variable, wrong is write tau = G+i:N_P-1
              	   d_ISI_tem = d_ISI_tem + 1/N_FFT*d1(n+1)*h(tau+1)*exp(j*2*pi*n*(i-tau)/N_FFT)*exp(-j*2*pi*l*(i-N_FFT-G)/N_FFT);
	    	end;
	   end;  
   end;
d_ISI = [d_ISI,d_ISI_tem];
end;






d_total = d_u1+d_u2 +d_ICI +d_ISI;

d_Cancellation = [d_Cancellation;d_total];
end;

d_c = [];
for loop=1:floor(length(QPSK_Symbol)/N_C);

d_c = [d_c,d_Cancellation(loop,:)];
end;


plot(real(d_c),'r.-');
hold on;
plot(real(received_signal));
hold off;
zoom on;
grid on;
legend('caculated signal in Matlab','received signal in COSSAP');




