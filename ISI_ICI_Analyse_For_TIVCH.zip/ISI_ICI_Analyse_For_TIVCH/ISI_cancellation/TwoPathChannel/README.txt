

-- In this directory, the static two paths channel is performed --

1/  ComparationOfCosMatResults.m  compares signal obtained in COSSAP with theoretical calculation.


2/ ISI_cancel_algorithm1.m : ISI cancellation according to algorithm 1


3/ ISI_cancel_algorithm2.m : ISI cancellation according to algorithm 2


