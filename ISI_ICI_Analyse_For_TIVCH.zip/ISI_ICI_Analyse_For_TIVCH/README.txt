

1/  HIP_Parameter:  ISI and ICI power calculation (ofdm workshop in Hamburg)

2/  ISI_ICI2_power: ISI and ICI power calculation (IEEE jounal)

3/  ISI_cancellation: ISI cancellation

4/  useful_signal_caused_by_channel2: Calculation of signal caused by channel2

    - Channel 2 is the channel outside the guard interval

5/  verify_ISI:  A correct formular to calculate ISI distribution




