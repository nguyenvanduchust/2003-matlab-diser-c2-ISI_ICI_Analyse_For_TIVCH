%------------------------------------------------------------------------------------------
% Dieses Program pr�ft, wenn die Orthogonalit�t des OFDM-Signals erf�llt ist,
% wird das emfangene Signal im Empf�nger freische ICI Rauschen detektiert.
% Dies gilt, wenn der Mobilfunkkanal ideal ist.
% empfangene SignalZ_l wird berechnet wie Gleichung (6, Seite VII)
% St�rsignal wurde berechnet wie Gleichung 7, Seite VII
% 16.02.01
%-----------------------------------------------------------------------------------------

%----------------------------------------------------------------------------------------
% Eingabe die Anzahl der Subtr�ger
%----------------------------------------------------------------------------------------

%N_C = input('Anzahl der Subtr�ger..............[N_C] :');

 N_C =16 ;

%----------------------------------------------------------------------------------------
% Eingabe die Guardintervall-Lange
%----------------------------------------------------------------------------------------

%G = input('Lange des Guardintervall..............[G] :');
 G = 4;
%-----------------------------------------------------------------------------------------
% Eingabe des gesendete Symbole
%-----------------------------------------------------------------------------------------

% gesendete QPSK symbol
load QPSK_Symbol_Real.am -ascii;
QPSK_Symbol_Real = QPSK_Symbol_Real(:,2);
load QPSK_Symbol_Img.am -ascii;
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);

QPSK_Symbol = QPSK_Symbol_Real + j* QPSK_Symbol_Img;




%------------------------------------------------------------------------------
% Berechne das gesendete OFDM - Signal (Nach FFT)
%-----------------------------------------------------------------------------



x_guard = OFDM_Signal(QPSK_Symbol,G);

%---------------------------------------------------------------------------------------
% Definire den TU-Kanal nach COS 207
%---------------------------------------------------------------------------------------

h = [0.5, 1, 0.63, 0.25, 0.16, 0.1];

h = [h, zeros(1, N_C - length(h))]; %Kanalsto�antwort

H = fft(h); %Kanal�bertragungsfunktion

%---------------------------------------------------------------------------------------
% Welche Subtr�ger m�chten Sie detektieren ?
%---------------------------------------------------------------------------------------

%n = input('Welche Subtr�ger m�chten Sie detektieren ?..[n]  :');
  n = 4;

%---------------------------------------------------------------------------------------
% stell das entsprechende Symbol in Bildschirm dar 
%---------------------------------------------------------------------------------------



disp('das gesendete Symbol ist '); disp(a(n));

%---------------------------------------------------------------------------------------
% Berechne die ICI-rauschen
%--------------------------------------------------------------------------------------

n = n-1 % da die erster Subtr�ger 0 ist

y_ICI = 0;

for k = 0:1:N_C -1;
    x_k = 0;
    for p = 0:1:N_C -1;
        if p ~= n
           tem = 1/N_C * a(p+1)* H(n+1)*exp(j*2*pi * k*(p-n)/N_C);
           x_k = tem + x_k;
        end;
        
    end;
    y_ICI = y_ICI + x_k;
end;


disp('das ICI Rauschen ist ') ; disp(y_ICI);


%---------------------------------------------------------------------------------------
% Berechne das detektierte Symbols 
%
%---------------------------------------------------------------------------------------


Z_l = 0;

for k = 0:1:N_C -1;
    x_k = 0;
    for p = 0:1:N_C -1;
        if p == n
           tem = 1/N_C * a(p+1)*H(p+1)*exp(j*2*pi * k*(p-n)/N_C);
           x_k = tem + x_k;
        end;
        
    end;
    Z_l = Z_l + x_k;
end;

disp('das detektierte Symbol ist ') ; disp(Z_l);


