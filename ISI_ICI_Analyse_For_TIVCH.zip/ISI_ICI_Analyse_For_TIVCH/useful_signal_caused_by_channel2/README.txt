

This directory contains the  results ontained by simulating file
 'VerifySignalCausedByChannel2.sch' in COSSAP, then compare with
 the corresponding results obtained by simulating file 
'VerifySignalCausedByChannel2.m' in MATLAB.

The comparision results are:

OFDM_Signal_Real is OFDM signal in COSSAP
Signal_AfterChannel_Real is the signal after traveling channel 2
Signal_AfterExtract_Real is the signal after extracting the guard interval

u_signal_caused_by_channel2 is the received signal after FFT.

The reader should references the paper:

intercarrier and intersymbol interference analysis of OFDM system 
over fading channels: OFDM-Workshop in Hamburg, 2001

file: VerifySignalCausedByChannel2.sch in COSSAP
file: 'VerifySignalCausedByChannel2.m' in MATLAB.




