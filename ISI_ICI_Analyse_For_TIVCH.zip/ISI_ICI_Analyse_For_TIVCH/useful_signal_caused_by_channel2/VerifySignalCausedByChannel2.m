%**************************************************************************************
% This program verifies the signal caused by the channel2, which obtained in COSSAP, 
% 'circuit: VerifySignalCausedByChannel2.sch' by comparing with result in MATLAB.
%  1> 'OFDM_Signal_Real' - real term of OFDM signal in COSSAP compared with 'x_guard' is
%  OFDM signal computed in MATLAB.  
%  2> 'Signal_AfterChannel_Real' is signal after the channel
%  compared with the 'y' is signal computed in MATLAB. 
%  3> 'Signal_AfterExtract_Real' is the signal when the guard interval is removed. This
%  signal is compared with the signal 'y_extract' of MATLAP
%  4> After extracting the guard interval, the signal is demuxed into two parts. One belongs
%  area I (see paper published in OFDM-Workshop 2001), the other belongs area II.
%  'Signal_after_expand' is compared with 'y_demux2' of MALTAB. 
%  5> After fft of 'y_demux2', we obtained 'y_received', which compared with 
%  'u_signal_caused_by_channel2' of COSSAP. 
%  6> However, the signal caused by channel 2 can be computed  according eq. 28 (second term)
%  Final result is 'y_theory',which is identical to 'y_received' (MATLAB) or 
%  'u_signal_caused_by_channel2' in COSSAP.
% 
% all the results in COSSAP agree absolutely with the results computed in MATLAB. This have proved
% the reliability of the paper
% COSSAP file  VerifySignalCausedByChannel2.sch, MATLAB file VerifySignalCausedByChannel2.m
% Van Duc Nguyen, 12.10.01
%**************************************************************************************


N_C =64; % the number of subcarrier is equal to the FFT length

%----------------------------------------------------------------------------------------
% The guard interval length
%----------------------------------------------------------------------------------------

%G = input('Lange des Guardintervall..............[G] :');
 G = 3;
%-----------------------------------------------------------------------------------------
% The QPSK symbol is loaded from COSSAP results
%-----------------------------------------------------------------------------------------

load QPSK_Symbol_Real.am -ascii;
QPSK_Symbol_Real = QPSK_Symbol_Real(:,2);
load QPSK_Symbol_Img.am -ascii;
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);

load OFDM_Signal_Real.am -ascii; % load the OFDM signal from COSSAP results
OFDM_Signal_Real = OFDM_Signal_Real(:,2);
load Signal_AfterChannel_Real.am -ascii; % load the signal after traveling channel 2
Signal_AfterChannel_Real = Signal_AfterChannel_Real(:,2);

load Signal_AfterExtract_Real.am -ascii; % load the signal of after removing guard interval
Signal_AfterExtract_Real = Signal_AfterExtract_Real(:,2);

 
load Signal_after_expand.am -ascii; % load the signal after demuxing end expanding in COSSAP
Signal_after_expand = Signal_after_expand(:,2);
load u_signal_caused_by_channel2.am -ascii; % load the received signal caused by channel 2
u_signal_caused_by_channel2 = u_signal_caused_by_channel2(:,2);


QPSK_Symbol = QPSK_Symbol_Real' + j* QPSK_Symbol_Img';




%------------------------------------------------------------------------------
% Berechne das gesendete OFDM - Signal (Nach FFT)
%-----------------------------------------------------------------------------



x_guard = OFDM_Signal(QPSK_Symbol,G)*N_C/sqrt(N_C);

%---------------------------------------------------------------------------------------
% Definiere den Kanal
%---------------------------------------------------------------------------------------

h = [0,0,0,0,0,0,0,0,0.5]; %Kanalsto�antwort
N_P = length(h);
h_full = [h, zeros(1, N_C - length(h))]; %Kanalsto�antwort
H_full = fft(h_full);

%-----------------------------------------------
% Signal nachdem dem Kanal
%----------------------------------------------

y = conv(h,x_guard);

%---------------------------------------------
% Signal after demuxing into to parts
%-------------------------------------------
y_extract = y(G+1:N_C+G);

y_demux1 = [y_extract(1:N_P-G),zeros(1, N_C-(N_P-G))]; % signal of part I is expaned by inserting zeros
y_demux2 = [zeros(1,N_P-G),y_extract(N_P-G+1:N_C)]; % signal of part II is expaned by inserting zeros
y_received = fft(y_demux2) * sqrt(N_C)/N_C; 
% received signal after FFT and multiplexing with a factor associated with factor in COSSAP


%-------------------------------------------------------
% Signal will be computed according to eq. (28), second term.
%------------------------------------------------------

y_theory=[];
for l=1:N_C;
    y_tem = 0;
    for i= N_P - G+1:N_C; % Should consider i variable from N-P-G+1
         for n=1:N_C;
             y_tem = y_tem +1/N_C* QPSK_Symbol(n)*H_full(n)*exp(j*2*pi*((n-1)-(l-1))*(i-1)/N_C);
         end;
    end;
y_theory = [y_theory,y_tem];
end;

plot(u_signal_caused_by_channel2); % put the cossap result in screen
hold on;
plot(real(y_received),'r.');      % put the verified matlab result in screen
plot(real(y_theory),'kx');        
% put the result accoding the analytical result of the paper, 
% which published in OFDM workshop in Hamburg
hold off;

legend('useful signal caused by channel 2 obtained in COSSAP', 'Matlab result','Theory according to term 2, eq. 28',0);

zoom on;
grid on;





