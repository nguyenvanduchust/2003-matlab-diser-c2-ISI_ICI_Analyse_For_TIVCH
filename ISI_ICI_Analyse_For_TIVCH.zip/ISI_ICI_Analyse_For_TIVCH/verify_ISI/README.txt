


This directory contains the program verify_ISI.m which gives correct 
calculation of d(ISI) described in eq. 35 in paper published in 
OFDM Workshop Hamburg 2001.

While impelemting we have detected that the eq. 35 should be corrected by 
changing the exponential function concerning variable tau 
exp(j*2*pi*m*(t-tau)/T_S)* exp(-j*2*pi*l*(t-iT'S)/T_S)

all results have been compared with cossap result in file
VerifySignalCausedByChannel2.sch in COSSAP


