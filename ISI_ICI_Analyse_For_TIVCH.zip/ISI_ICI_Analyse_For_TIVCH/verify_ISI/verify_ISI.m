%------------------------------------------------------------------------
% This program calculate the d_ISI component according to eq. 33 in paper
% published in OFDM workshop 2001 Hamburg. In implementing we habe recognized
% that the eq. should be corrected as this program
%-----------------------------------------------------------------------


clear;
load QPSK_Symbol_Img.am -ascii; % the QPSK symbols in COSSAP are loaded
load QPSK_Symbol_Real.am -ascii;
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);
QPSK_Symbol_Real = QPSK_Symbol_Real(:,2);
QPSK_Symbol = QPSK_Symbol_Real + j*QPSK_Symbol_Img;

load OFDM_Signal_Real.am -ascii; % The OFDM signal in COSAP are loaded
OFDM_Signal_Real = OFDM_Signal_Real(:,2);
load Signal_AfterChannel_Real.am -ascii; 
Signal_AfterChannel_Real = Signal_AfterChannel_Real(:,2);
%The signal ater traveling via multipath channel are loaded

load Signal_AfterExtract_Real.am -ascii; 
% Signal after subtracting guard length

Signal_AfterExtract_Real = Signal_AfterExtract_Real(:,2);



load ISI_d_term3.am -ascii; %ISI+ ICI_2 are loaded
ISI_d_term3 = ISI_d_term3(:,2);


%-----------------------------------------------------------------------------
% Definiere den Kanal
%-----------------------------------------------------------------------------
N_C = 64;
N_FFT = 64;
G = 3;
ho = [0,0,0,0,0,0,0,0,0.5]; %Kanalsto�antwort
N_P = length(ho);
h2 = [ho, zeros(1, N_C - length(ho))]; %Kanalsto�antwort
d1 = QPSK_Symbol(1:64);
d2 = QPSK_Symbol(65:128);

% calculation of OFDM signal in MATLAB
OFDM_Signal_Matlab1 = OFDM_Signal(d1,G);
OFDM_Signal_Matlab2 = OFDM_Signal(d2,G);




%-------------------------------------------------------------------------
% calculation of ISI
%------------------------------------------------------------------------

%****************************************************************************
d_ISI_MATLAB = [];
for l=0:N_FFT-1;
d_tem = 0;
for nt = 0: N_P -G-1; % nt correspondes to t variable in eq.35
    
    for n =0:N_FFT-1;
        for tau = (nt+N_FFT+G)-N_FFT+1:N_P-1;
                   d_tem = d_tem + 1/N_FFT*d1(n+1)*ho(tau+1)*exp(j*2*pi*n*(nt+N_FFT+G-tau)/N_FFT)*exp(-j*2*pi*l*nt/N_FFT);
% see that to obtain correct d_ISI, the (eq. 35) must be corrected               
                
        end;
    
    end;
    
end;
d_ISI_MATLAB = [d_ISI_MATLAB,d_tem];
end;

%***************************************************************************
% d_ISI can be computed in the same way, where the bounds nt variable has 
% been changed
%--------------------------------------------------------------------------

d_ISI_M = [];
for l=0:N_FFT-1;
d_tem = 0;
for nt = N_FFT+G: N_FFT+N_P-1; %changed bounds of nt variable
    
    for n =0:N_FFT-1;
        for tau = nt-N_FFT+1:N_P-1;
                   d_tem = d_tem + 1/N_FFT*d1(n+1)*ho(tau+1)*exp(j*2*pi*n*(nt-tau)/N_FFT)*exp(-j*2*pi*l*(nt-N_FFT-G)/N_FFT);
% if the bounds of nt variable changed, then the eq. 35 have to change as above
                
        end;
    
    end;
    
end;
d_ISI_M = [d_ISI_M,d_tem];
end;



OFDM_Signal_Matlab_x1 = [OFDM_Signal_Matlab1,zeros(1,length(OFDM_Signal_Matlab2))]; % first OFDM symbol

OFDM_Signal_Matlab_x2 = [zeros(1,length(OFDM_Signal_Matlab1)),OFDM_Signal_Matlab2]; % second OFDM symbol

Signal_AfterChannel_matlab1 = conv(ho,OFDM_Signal_Matlab_x1); % convolutional with the channel
Signal_AfterChannel_matlab2 = conv(ho,OFDM_Signal_Matlab_x2);

y_ISI = Signal_AfterChannel_matlab1(N_C+2*G+1:N_C+G+N_P); 
% the ISI term  corresponeds to the area IV caused by the first symbol  have to be extracted
y_ISI_expand = [y_ISI,zeros(1,N_C-length(y_ISI))]; % y_ISI_expand have been compared with the results in COSSAP
d_ISI_corect = fft(y_ISI_expand); 


plot(real(d_ISI_corect),'r.-');
hold on;
plot(real(d_ISI_M),'bx-');
legend('The d(ISI) obtained in COSSAP', 'the d(ISI) caculated as in verified eq. 35',0);
hold off;
zoom on;
grid on;
