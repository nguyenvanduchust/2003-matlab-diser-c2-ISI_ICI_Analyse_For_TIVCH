clear;
load QPSK_Symbol_Img.am -ascii;
load QPSK_Symbol_Real.am -ascii;
QPSK_Symbol_Img = QPSK_Symbol_Img(:,2);
QPSK_Symbol_Real = QPSK_Symbol_Real(:,2);
load OFDM_Signal_Real.am -ascii;
OFDM_Signal_Real = OFDM_Signal_Real(:,2);
load Signal_AfterChannel_Real.am -ascii;
Signal_AfterChannel_Real = Signal_AfterChannel_Real(:,2);

load Signal_AfterExtract_Real.am -ascii;
Signal_AfterExtract_Real = Signal_AfterExtract_Real(:,2);

QPSK_Symbol = QPSK_Symbol_Real + j*QPSK_Symbol_Img;

load ISI_d_term3.am -ascii;
ISI_d_term3 = ISI_d_term3(:,2);


%-----------------------------------------------------------------------------
% Definiere den Kanal
%-----------------------------------------------------------------------------
N_C = 64;
N_FFT = 64;
G = 3;
ho = [0,0,0,0,0,0,0,0,0.5]; %Kanalsto�antwort
N_P = length(ho);
h2 = [ho, zeros(1, N_C - length(ho))]; %Kanalsto�antwort
d1 = QPSK_Symbol(1:64);
d2 = QPSK_Symbol(65:128);

OFDM_Signal_Matlab1 = OFDM_Signal(d1,G);
OFDM_Signal_Matlab2 = OFDM_Signal(d2,G);




%-------------------------------------------------------------------------
% calculation of ISI
%------------------------------------------------------------------------
x = [];
for t=-G:N_C-1;
tem = 0;
for n=1:N_C;
tem = tem + 1/N_FFT*d1(n)*exp(j*2*pi*(n-1)*t/N_C);
end;
x = [x, tem];
end;
clear tem;

y_formel = [];
for k = -G:N_FFT+N_P-1;
    y_k = 0;
    for m =0:N_P-1;
        tem_n = 0;
        for n = 0:N_C -1;
               if( k-m >= -G) & (k-m<=N_FFT -1)
                  tem_n = tem_n  + ho(m+1)*d1(n+1)* exp(j*2* pi * n * (k-m)/N_FFT);
                else
                  tem_n = tem_n;
                end;

        end;
    y_k = y_k + tem_n * 1/N_FFT;
    end;
y_formel = [y_formel,y_k];
end;

y_ISI_MATLAB = [];
for t=N_FFT+G: N_FFT+N_P-1;
    d_tem = 0;
    for n =0:N_FFT-1;
        for tau = t-N_FFT+1:N_P-1; % very important for setting bound of variables
                %if(t-tau >= -G)&(t-tau <=N_FFT-1);
                   d_tem = d_tem + 1/N_FFT*d1(n+1)*ho(tau+1)*exp(j*2*pi*n*(t-tau)/N_FFT);
                %end;
                
        end;
    
    end;
    y_ISI_MATLAB = [y_ISI_MATLAB,d_tem];
end;
d_ISI_MAT = fft([y_ISI_MATLAB, zeros(1,N_FFT-length(y_ISI_MATLAB))]);
%y_ISI_MATLAB = [y_ISI_MATLAB, zeros(1,N_FFT-length(y_ISI_MATLAB))];

d_ISI_test = [];
for l=0:N_FFT-1;
    d_tem = 0; 
    for n=0:N_P-G-1;
        d_tem = d_tem + y_ISI_MATLAB(n+1)*exp(-j*2*pi*l*n/N_FFT);
    end;
d_ISI_test = [d_ISI_test,d_tem];
end;


%****************************************************************************
d_ISI_MATLAB = [];
for l=0:N_FFT-1;
d_tem = 0;
for nt = 0: N_P -G-1;
    
    for n =0:N_FFT-1;
        for tau = (nt+N_FFT+G)-N_FFT+1:N_P-1;
                   d_tem = d_tem + 1/N_FFT*d1(n+1)*ho(tau+1)*exp(j*2*pi*n*(nt+N_FFT+G-tau)/N_FFT)*exp(-j*2*pi*l*nt/N_FFT);
               
                
        end;
    
    end;
    
end;
d_ISI_MATLAB = [d_ISI_MATLAB,d_tem];
end;

%***************************************************************************


d_ISI_M = [];
for l=0:N_FFT-1;
d_tem = 0;
for nt = N_FFT+G: N_FFT+N_P-1;
    
    for n =0:N_FFT-1;
        for tau = nt-N_FFT+1:N_P-1;
                   d_tem = d_tem + 1/N_FFT*d1(n+1)*ho(tau+1)*exp(j*2*pi*n*(nt-tau)/N_FFT)*exp(-j*2*pi*l*(nt-N_FFT-G)/N_FFT);
               
                
        end;
    
    end;
    
end;
d_ISI_M = [d_ISI_M,d_tem];
end;



OFDM_Signal_Matlab_x1 = [OFDM_Signal_Matlab1,zeros(1,length(OFDM_Signal_Matlab2))];

OFDM_Signal_Matlab_x2 = [zeros(1,length(OFDM_Signal_Matlab1)),OFDM_Signal_Matlab2];

Signal_AfterChannel_matlab1 = conv(ho,OFDM_Signal_Matlab_x1);
Signal_AfterChannel_matlab2 = conv(ho,OFDM_Signal_Matlab_x2);

y_ISI = Signal_AfterChannel_matlab1(N_C+2*G+1:N_C+G+N_P);
y_ISI_expand = [y_ISI,zeros(1,N_C-length(y_ISI))];
d_ISI_corect = fft(y_ISI_expand);



figure(2);


plot(real(d_ISI_corect),'r.-');
hold on;

plot(real(d_ISI_M),'bx-');

hold off;
zoom on;
grid on;
